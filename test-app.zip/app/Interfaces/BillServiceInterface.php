<?php
namespace App\Interfaces;

interface BillServiceInterface {

    public function calculateBill($units);

}
